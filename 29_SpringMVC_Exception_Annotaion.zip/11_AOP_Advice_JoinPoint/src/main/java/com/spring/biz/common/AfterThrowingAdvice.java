package com.spring.biz.common;

import org.aspectj.lang.JoinPoint;

public class AfterThrowingAdvice {
//	public void execeptionLog() {
//		System.out.println("[후처리-AfterThrowingAdvice.execeptionLog]"
//				+ "비즈니스 로직 수행 중 예외 발생 시 로그");
//	}
	
	// 예외 객체 전달 받을 수 있음
	//  exceptObj : 스프링 설정 파일에 설정 추가 
	public void execeptionLog(JoinPoint jp, Exception exceptObj) {
		
		if(exceptObj instanceof IllegalArgumentException) {
			System.out.println(">> 부적합한 값이 전달되었습니다.");
		} else if(exceptObj instanceof NumberFormatException) {
			System.out.println(">> 숫자 형식이 아닙니다.");
		} else if(exceptObj instanceof Exception) {
			System.out.println(">> 예외가 발생했습니다.");
		}
		
		System.out.println("[후처리-예외발생] 예외메세지 : " + exceptObj.getMessage());
	}
}
