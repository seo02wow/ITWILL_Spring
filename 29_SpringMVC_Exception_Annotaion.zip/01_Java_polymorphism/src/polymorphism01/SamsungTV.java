package polymorphism01;

public class SamsungTV {
	public void powerOn() {
		System.out.println(">> SamsungTV - 전원ON ");
	}
	public void powerOff() {
		System.out.println(">> SamsungTV - 전원OFF ");
	}
	public void volumeUp() {
		System.out.println(">> SamsungTV - 소리 크게 ");
	}
	public void volumeDown() {
		System.out.println(">> SamsungTV - 소리 작게 ");
	}
}

