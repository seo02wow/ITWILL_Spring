package polymorphism01;

public class LgTV {
	public void on() {
		System.out.println(">> LgTV - 전원 ON");
	}
	public void off() {
		System.out.println(">> LgTV - 전원 OFF");
	}
	public void soundUp() {
		System.out.println(">> LgTV - 소리 크게");
	}
	public void soundDown() {
		System.out.println(">> LgTV - 소리 작게");
	}
	
}
