package polymorphism02;

public interface TV { // 결합도 낮추기 위함 
	public void powerOn();
	public void powerOff();
	public void volumeUp();
	public void volumeDown();
	
}
