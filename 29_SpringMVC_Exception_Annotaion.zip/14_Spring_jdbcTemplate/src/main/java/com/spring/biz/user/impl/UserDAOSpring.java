package com.spring.biz.user.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.spring.biz.user.UserVO;

@Repository
public class UserDAOSpring {
	private JdbcTemplate jdbcTemplate;
	
	//SQL문 
	private final String USER_GET
		="SELECT * FROM USERS WHERE ID = ? AND PASSWORD = ?";
	
	public UserDAOSpring() {
		System.out.println(">> UserDAOSpring() 객체 생성");
	}
	
	@Autowired // 생성자에 @Autowired 설정해서 의존주입(DI) 처리 
	public UserDAOSpring(JdbcTemplate jdbcTemplate) {
		System.out.println(">> UserDAOSpring(jdbcTemplate) 생성");
		System.out.println("jdbcTemplate : " + jdbcTemplate);
		this.jdbcTemplate = jdbcTemplate; 
	}
	
	public UserVO getuser(UserVO vo) {
		System.out.println("==>> Spring JDBC로 getuser() 실행");
		
		Object[] args = {vo.getId(), vo.getPassword()};
		return jdbcTemplate.queryForObject(USER_GET, args, new UserRowMapper());
		
	}
}
