package com.spring.biz.view.board;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.spring.biz.board.BoardVO;
import com.spring.biz.board.impl.BoardDAO;

@Controller
public class DeleteBoardController{
	
	@RequestMapping("/deleteBoard.do")
	public String handleRequest(BoardVO vo, BoardDAO boardDAO){
		System.out.println(">>> 게시글 삭제");
		//1. 전달받은 데이터 확인(추출) 
	
		//2. DB 연동작업(삭제)
		boardDAO.deleteBoard(vo);
		
		//3. 페이지 전환
		
		// 화면전환만 필요할 경우 String 리턴 
		// 모델앤뷰는 무거움
		return "getBoardList.do";
	}

}
