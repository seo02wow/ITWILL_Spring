package com.spring.biz.view.board;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.spring.biz.board.BoardVO;
import com.spring.biz.board.impl.BoardDAO;

@Controller
public class GetBoardController {
	@RequestMapping("/getBoard.do")
	public ModelAndView getBoard(BoardVO vo,BoardDAO boardDAO,ModelAndView mav) {
		System.out.println(">>> 게시글 상세 보여주기");
		System.out.println("vo : " + vo);
		
		//2-1. DB 연동작업(게시글 1개 조회)  
		BoardVO board = boardDAO.getBoard(vo);
		
		mav.addObject("board", board); // 데이터 저장
		mav.setViewName("getBoard.jsp"); // 화면 전환
		
		
		return mav;
	}

}
