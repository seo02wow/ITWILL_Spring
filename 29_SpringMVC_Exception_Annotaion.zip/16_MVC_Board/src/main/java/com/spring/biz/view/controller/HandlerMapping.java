package com.spring.biz.view.controller;

import java.util.HashMap;
import java.util.Map;

import com.spring.biz.view.board.DeleteBoardController;
import com.spring.biz.view.board.GetBoardController;
import com.spring.biz.view.board.GetBoardListController;
import com.spring.biz.view.board.InsertBoardController;
import com.spring.biz.view.board.UpdateBoardController;
import com.spring.biz.view.controller.user.LoginController;
import com.spring.biz.view.controller.user.LogoutController;

// HandlerMapping : 요청정보와 처리할 컨트롤러를 연결하는 정보를 저장 및 관리하는 클래스 
// 요청 <-> 컨트롤러 연결 
public class HandlerMapping {
	// 요청명과 처리할 컨트롤러 정보를 가지고 있는 클래스 
	// Controller : 스프링이 제공하는 컨트롤러 아님 
	private Map<String, Controller> mappings;
	
	public HandlerMapping() {
		mappings = new HashMap<String, Controller>();
		///login.do가 들어오면 LoginController 수행 
		mappings.put("/login.do", new LoginController());
		mappings.put("/logout.do", new LogoutController());
		mappings.put("/getBoardList.do", new GetBoardListController());
		mappings.put("/getBoard.do", new GetBoardController());
		
		mappings.put("/insertBoard.do", new InsertBoardController());
		mappings.put("/updateBoard.do", new UpdateBoardController());
		mappings.put("/deleteBoard.do", new DeleteBoardController());
		
	}
	
	public Controller getController(String path) {
		return mappings.get(path);
	}
	
}
