package com.spring.biz.view.controller;

public class DeleteBoardController {

}
