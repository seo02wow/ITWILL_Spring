package com.spring.biz.view.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerExecutionChain;

import com.spring.biz.board.BoardVO;
import com.spring.biz.board.impl.BoardDAO;
import com.spring.biz.user.UserVO;
import com.spring.biz.user.impl.UserDAO;

public class DispatcherServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;  
	private HandlerMapping handlerMapping;
	private ViewResolver viewResolver;
	
	@Override
	public void init() throws ServletException {
		handlerMapping = new HandlerMapping();
		viewResolver = new ViewResolver();
		viewResolver.setPrefix("./"); //위치경로
		viewResolver.setSuffix(".jsp"); //파일타입(확장명)
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("DispatcherServlet.process() : *.do 요청처리~");
		//1. 클라이언트에서 어떤 작업을 요청헀는지 확인하기 
		String uri = request.getRequestURI(); //  '/biz/login.do'
		System.out.println("uri : " + uri);  
		String path = uri.substring(uri.lastIndexOf('/'));
		System.out.println("path : " + path);  
		
		//2. 클라이언트 요청형태에 따른 작업 처리
		//path : 요청명 
		Controller controller = handlerMapping.getController(path);
		System.out.println("controller : " + controller);
		
		String viewName = controller.handleRequest(request, response); // 작업처리 후 문자열(뷰명칭) 전달
		System.out.println(">> viewName : " + viewName);
		
		//3.이동한 view 이름 정보를 작성하고 
		// viewName에 ".do" 가 없으면 뷰리졸버 적용 
		// 있으면 그대로 요청처리
		String view = null;
		if(viewName.contains(".do")) {
			view = viewName;
		} else {
			view = viewResolver.getView(viewName); // 접두어 접미어 붙임
		}
		System.out.println(">> view : " + view);
		//응답처리
		response.sendRedirect(view);
	}
	
	// 이전 process
//	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		System.out.println("DispatcherServlet.process() : *.do 요청처리~");
//		
//		//1. 클라이언트에서 어떤 작업을 요청헀는지 확인하기 
//		String uri = request.getRequestURI(); //  '/biz/login.do'
//		System.out.println("uri : " + uri);  
//		String path = uri.substring(uri.lastIndexOf('/'));
//		System.out.println("path : " + path);  
//		
//		//2. 클라이언트 요청형태에 따른 작업 처리
//		if("/getBoard.do".equals(path)) {
//			System.out.println(">>> 게시글 상세 보여주기");
//			
//			//1. 전달받은 데이터 확인(추출) 
//			int seq = Integer.parseInt(request.getParameter("seq"));
//			
//			//2-1. DB 연동작업(게시글 1개 조회)  
//			BoardDAO boardDAO = new BoardDAO();
//			BoardVO vo = new BoardVO();
//			vo.setSeq(seq);
//			
//			BoardVO board = boardDAO.getBoard(vo);
//			
//			//2-2. 검색 결과를 세션에 저장(뷰에서 사용 가능하도록)
//			HttpSession session = request.getSession();
//			session.setAttribute("board", board);
//			
//			//3. 화면 전환 (상세페이지로 이동)
//			response.sendRedirect("getBoard.jsp");
//		}
//		
//		if("/updateBoard.do".equals(path)) {
//			System.out.println(">>> 게시글 수정");
//			//1. 전달받은 데이터 확인(추출) 
//			int seq = Integer.parseInt(request.getParameter("seq"));
//			String title = request.getParameter("title");
//			String content = request.getParameter("content");
//			String writer = request.getParameter("writer");
//			
//			//2. DB 연동작업(수정)
//			BoardVO vo = new BoardVO();
//			vo.setSeq(seq);
//			vo.setTitle(title);
//			vo.setContent(content);
//			vo.setWriter(writer);
//			
//			BoardDAO boardDAO = new BoardDAO();
//			boardDAO.updateBoard(vo);
//			
//			//3. 페이지 전환
//			// 수정된 데이터와 함께 목록페이지로 이동
//			response.sendRedirect("getBoardList.do");
//		}
//		if("/deleteBoard.do".equals(path)) {
//			System.out.println(">>> 게시글 삭제");
//			//1. 전달받은 데이터 확인(추출) 
//			int seq = Integer.parseInt(request.getParameter("seq"));
//			BoardVO vo = new BoardVO();
//			vo.setSeq(seq);
//			
//			//2. DB 연동작업(삭제)
//			BoardDAO boardDAO = new BoardDAO();
//			boardDAO.deleteBoard(vo);
//			
//			//3. 페이지 전환
//			response.sendRedirect("getBoardList.do");
//		}
//		
//	}
}
