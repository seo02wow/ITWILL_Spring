package com.spring.biz.common;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

import org.springframework.stereotype.Service;

@Aspect //포인트컷 + 어드바이스 연결
@Service //객체(인스턴스) 생성
public class BeforeAdvice {
	// 어드바이스 동작시점 설정 + 포인트컷 지정
	 //PointcutCommon 클래스에 있는  allPointcut 사용 
	@Before("PointcutCommon.allPointcut()")
	public void beforeLog() {
		System.out.println("[사전처리-BeforeAdvice.beforeLog]"
				+ "비즈니스 로직 수행전 로그");
	}
}
