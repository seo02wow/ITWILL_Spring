package polymorphism04;

public interface Speaker {
	public void volumnUp();
	public void volumnDown();
}
