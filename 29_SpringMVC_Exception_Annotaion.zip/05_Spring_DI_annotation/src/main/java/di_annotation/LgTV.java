package di_annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

//(실습) Speaker 추가하고 @Component, @Autowired, @Qualifier 추가해서 설정 
@Component("tv2") // tv2라는 명칭으로 객체 생성 
//(별도로 지정하지 않았을 경우 클래스명 첫글자 소문자로 명칭이 지정됨)
public class LgTV implements TV {
	@Autowired
	@Qualifier("sony") // 스피커가 sony와 apple이 있음 
	// 특정 하나를 지정해주지 않으면 sony와 apple이 충돌해서 오류남 
	private Speaker speaker;
	
	public Speaker getSpeaker() {
		return speaker;
	}

	public void setSpeaker(Speaker speaker) {
		this.speaker = speaker;
	}
	

	public LgTV() {
		System.out.println(">> LgTV() 객체 생성");
	}
	
	@Override
	public void powerOn() {
		System.out.println("LgTV - 전원ON");
	}
	@Override
	public void powerOff() {
		System.out.println("LgTV - 전원OFF");
	}
	@Override
	public void volumeUp() {
		System.out.println("LgTV - 소리크게~~~");
	}
	@Override
	public void volumeDown() {
		System.out.println("LgTV - 소리작게~~~");
	}
}
